# Graph Algorithm (What)

A python library for running shortest path algorithms on graphs. Find the shortest path of graphs using Dijkstra's algorithm.


##


##


## How to install and build the graphs_mcsteestu library
'''
pip3 install graphs_mcsteestu
'''

## How to use the graphs_mcsteestu library


## Credits
* Dr. Mota for providing the code for Dijkstra's algorithm.



## Licence
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)